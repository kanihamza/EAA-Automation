
// DGO R11.6 Figma UI/UX runtime enhancer: non-invasive, no framework, no endpoint changes.
// Guarded so the module is safely importable in non-browser (diagnostic) contexts.
if (typeof document !== 'undefined' && typeof window !== 'undefined' && typeof MutationObserver !== 'undefined') (function(){
  const root=document.documentElement;
  root.classList.add('dgo-figma-uiux-implemented');
  function closeDrawers(){ document.querySelectorAll('.dgo-drawer:not([hidden])').forEach(d=>d.hidden=true); }
  function scrubDemoStateCards(){
    const route=(location.hash||'#/home').replace(/^#\/?/,'')||'home';
    if(route==='diagnostics'||route==='operator-hud') return;
    const demoTexts=['Skeleton and last-good-data treatment available.','Empty-state copy is standardized.','Errors remain visible beyond transient toasts.'];
    document.querySelectorAll('.workspace .panel,.workspace .dgo-card,.workspace .card,.workspace section').forEach(node=>{
      const txt=(node.textContent||'').replace(/\s+/g,' ').trim();
      if(demoTexts.some(t=>txt.includes(t))){
        const host=node.parentElement;
        node.remove();
        if(host && host.children.length===0) host.remove();
      }
    });
  }

  document.addEventListener('click', function(e){
    const close=e.target.closest('[data-drawer-close]'); if(close){ closeDrawers(); }
    const open=e.target.closest('[data-open-drawer]'); if(open){ const d=document.querySelector(`[data-drawer="${CSS.escape(open.dataset.openDrawer)}"]`); if(d){ d.hidden=false; d.querySelector('button,input,select,textarea,a')?.focus(); }}
  }, true);
  document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeDrawers(); }, true);
  const obs=new MutationObserver(()=>{
    document.querySelectorAll('table').forEach(t=>{
      const heads=[...t.querySelectorAll('thead th')].map(th=>th.textContent.trim());
      t.querySelectorAll('tbody tr').forEach(tr=>[...tr.children].forEach((td,i)=>{ if(!td.hasAttribute('data-label') && heads[i]) td.setAttribute('data-label',heads[i]); }));
    });
    document.querySelectorAll('.panel h2 + .meta, .panel .meta + h2').forEach(x=>x.closest('.panel')?.classList.add('dgo-panel-contextual'));
    scrubDemoStateCards();
  });
  obs.observe(document.body,{childList:true,subtree:true});
  scrubDemoStateCards();
  window.addEventListener('hashchange',()=>requestAnimationFrame(scrubDemoStateCards));
})();
