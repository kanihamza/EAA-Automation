// Corrected audit P2: module-level surfaces must use shell/shared dialog infrastructure, not raw untrapped dialogs.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const shell=fs.readFileSync('shared/shell.js','utf8');
const components=fs.readFileSync('shared/components.js','utf8');
const modules=fs.readdirSync('modules').filter(f=>f.endsWith('.js')).map(f=>fs.readFileSync('modules/'+f,'utf8')).join('\n');
assert.match(shell,/_trapFocus\(surface\)/,'shell focus trap must exist');
assert.match(shell,/aria-modal=\"true\"/,'shell dialog/confirm surfaces must expose aria-modal');
assert.match(components,/role=\"dialog\" aria-modal=\"true\"/,'shared Dialog/Drawer/Command surfaces must expose dialog semantics');
assert.doesNotMatch(modules,/<dialog\b|document\.createElement\(['\"]dialog['\"]\)|class=\"[^\"]*modal[^\"]*\"/,'modules must not create raw untrapped modal/dialog surfaces');
console.log('modal-focus-coverage-contract passed');
