// Corrected audit P3: nested fetch failures must preserve UI and expose non-blocking empty/error state metadata.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const loader=fs.readFileSync('core/data-loader.js','utf8');
const boot=fs.readFileSync('core/boot.js','utf8');
const css=fs.readFileSync('styles/app.css','utf8');
assert.match(loader,/key:'deferred-runtime-data'/,'data loader must return a deferred/offline result instead of throwing when all initial fetches fail');
assert.match(loader,/lastWarnings:\[\.\.\.\(State\.get\(\)\.runtime\?\.lastWarnings\|\|\[\]\),message\]\.slice\(-10\)/,'data loader must retain diagnostics warning history');
assert.doesNotMatch(loader,/throw new Error\(message\)/,'initial nested fetch failure must not throw a blocking boot error');
assert.doesNotMatch(boot,/Live data could not be loaded:[^;]+,'error'/,'boot must not render a blocking red live-data toast');
assert.match(css,/\[data-error-state\]\{[^}]*border-inline-start:4px solid/s,'visible nested error state styling must exist for module-owned errors');
console.log('nested-fetch-empty-error-contract passed');
