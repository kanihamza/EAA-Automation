// Initial live-data failure must not render a blocking red error toast over the workspace.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const boot=fs.readFileSync('core/boot.js','utf8');
assert.doesNotMatch(boot,/Live data could not be loaded/,'boot must not show noisy red live-data error toast on initial load');
assert.match(boot,/data-load-deferred/,'boot must record deferred/offline live-data state for diagnostics');
assert.match(boot,/lastWarnings/,'boot must preserve diagnostics warning detail without blocking UI');
console.log('data-load-graceful-contract passed');
