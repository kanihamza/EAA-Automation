// Shell layout invariants:
//  - footer always present (has a :root --footer default, shell grid bounds its row,
//    and the footer is NOT display:none'd on short viewports);
//  - the main content area is the SINGLE scroll container — no nested/independent section
//    scrolling (master-detail panes and the record body must flow, not scroll on their own);
//  - the top-bar workspace identity is compact (small, non-wrapping);
//  - the redundant in-page intro header is suppressed platform-wide.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const css=fs.readFileSync('styles/app.css','utf8');
const ui=fs.readFileSync('core/ui.js','utf8');
const corr=fs.readFileSync('modules/correspondence.js','utf8');

// Footer present & pinned.
assert.match(css,/:root\{[^}]*--footer:\d+px/,'--footer must have a :root default');
assert.match(css,/\.dgo-shell-grid\{[^}]*grid-template-rows:minmax\(0,1fr\)/,'shell grid must bound its row so the footer stays in view');
assert.doesNotMatch(css,/max-height:640px\)\{[^}]*\.dgo-footer\{display:none\}/,'footer must not be hidden on short viewports');

// Single scroll container: main scrolls; panes and record body do not scroll independently.
assert.match(css,/\.dgo-main\{[^}]*overflow:hidden !important/,'main must be bounded and must not become the page scroll container');
assert.match(css,/\.split>\*[^}]*overflow:auto !important/s,'master-detail panes must scroll independently');
assert.match(css,/\.dg-layout>\.panel[^}]*overflow:auto !important/s,'DG layout panes must scroll independently');
assert.match(css,/\.record-body\{[^}]*overflow:auto !important/,'record body must scroll internally when long');

// Compact top-bar identity (small + non-wrapping).
assert.match(css,/\.dgo-route-title b\{font-size:1[0-3]px;[^}]*white-space:nowrap/,'workspace name must be small and non-wrapping');
assert.match(css,/\.dgo-route-title small\{font-size:[0-9]px/,'ACTIVE WORKSPACE eyebrow must be reduced');

// Condensed correspondence controls + suppressed intro header.
assert.match(css,/\.cc-controlbar\{/,'condensed control strip styles must exist');
assert.match(css,/\.cc-stat\{[^}]*height:2[0-9]px/,'metric pills must be compact (<= half header height)');
// The VISIBLE intro block (eyebrow + big title + subtitle) must be suppressed platform-wide; a single
// visually-hidden <h1> is retained so every workspace still exposes one programmatic heading (a11y).
assert.match(ui,/export const head = [^\n]*dgo-visually-hidden/,'head() must emit only a visually-hidden heading (no visible intro block)');
assert.doesNotMatch(ui,/export const head = [^\n]*(dgo-overline|pagehead|dgo-module-view__head)/,'head() must not render the visible eyebrow/pagehead intro block');
assert.doesNotMatch(corr,/class="dashboard-metrics"/,'duplicate status band must be removed from the tracker view');
assert.doesNotMatch(corr,/\$\{head\(/,'correspondence must not render the removed intro header');

console.log('layout-footer-contract passed');
