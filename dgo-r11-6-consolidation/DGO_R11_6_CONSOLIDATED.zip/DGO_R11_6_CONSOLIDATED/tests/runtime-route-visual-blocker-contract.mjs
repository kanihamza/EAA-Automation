// Screenshot blocker contract: active routes must not show demo state cards and must bound tracking/correspondence content.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync('styles/app.css','utf8');
const rt=fs.readFileSync('modules/response-tracking.js','utf8');
const corr=fs.readFileSync('modules/correspondence.js','utf8');
const runtime=fs.readFileSync('shared/figma-uiux-runtime.js','utf8');
assert.match(runtime,/function scrubDemoStateCards\(\)/,'runtime must scrub design-system demo state cards from active routes');
assert.match(runtime,/Skeleton and last-good-data treatment available/,'scrub target must include observed Loading card copy');
assert.match(css,/dgo-shell\[data-route="response-tracking"\] \.rt-workspace\{[^}]*grid-template-rows:auto auto minmax\(0,1fr\)/s,'response tracking must reserve KPI/filter/content rows');
assert.match(css,/dgo-shell\[data-route="response-tracking"\] \.rt-split\{[^}]*overflow:hidden !important/s,'response tracking split must be bounded');
assert.match(css,/dgo-shell\[data-route="response-tracking"\] \.dgo-table td:nth-child\(2\)\{[^}]*-webkit-line-clamp:2/s,'long execution-node text must clamp');
assert.match(rt,/class="workspace rt-workspace"/,'response tracking workspace must carry route-specific class');
assert.match(rt,/class="toolbar rt-toolbar"/,'response tracking toolbar must carry route-specific class');
assert.match(corr,/record-action-grid/,'correspondence actions must use compact action grid');
assert.match(css,/dgo-shell\[data-route="correspondence"\] \.record-action-grid\{[^}]*grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/s,'correspondence actions must not force a tall one-button-per-row stack by default');
console.log('runtime-route-visual-blocker-contract passed');
