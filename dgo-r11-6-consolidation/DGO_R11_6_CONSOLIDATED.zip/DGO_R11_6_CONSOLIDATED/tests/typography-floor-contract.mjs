// Corrected audit P2: persistent micro-type must have an explicit legibility floor.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync('styles/app.css','utf8');
assert.match(css,/\.ministry,\s*\n\.dgo-ministry-bar\{[^}]*font-size:11px !important/s,'ministry bar text must be raised to an 11px persistent-label floor');
assert.match(css,/\.grid label,[\s\S]*?\.help-text\{[^}]*font-size:max\(11px,.75rem\)/s,'field labels and persistent help text must have an 11px floor');
assert.match(css,/\.preview-table \.pill,[\s\S]*?\.dgo-source\{[^}]*font-size:max\(11px,.72rem\)/s,'pills/chips/status labels must have an 11px floor');
console.log('typography-floor-contract passed');
