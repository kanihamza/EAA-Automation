import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
const roots=['config','core','shared','modules'];
const files=roots.flatMap(d=>fs.readdirSync(d).filter(f=>f.endsWith('.js')).map(f=>path.join(d,f))).sort();
const failures=[];
for(const f of files){try{await import(pathToFileURL(path.resolve(f)).href+'?smoke='+Date.now());}catch(e){failures.push({file:f,error:e.message});}}
console.log(JSON.stringify({files:files.length,failures:failures.length,details:failures},null,2));
if(failures.length) process.exit(1);
