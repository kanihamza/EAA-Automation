// Screen containment contract: shell fits in 100dvh, footer remains reserved/visible,
// dgo-main is not a page scroll surface, and panes own their scrolling independently.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css = fs.readFileSync('styles/app.css','utf8');
function has(re, msg){ assert.match(css, re, msg); }
has(/html,\s*\nbody,\s*\n#app,\s*\ndgo-shell\{[^}]*block-size:100dvh[^}]*overflow:hidden !important/s, 'html/body/#app/dgo-shell must lock to 100dvh and hide viewport scroll');
has(/dgo-shell\{[^}]*contain:layout size/s, 'dgo-shell must contain layout and size');
has(/\.dgo-workarea\{[^}]*display:grid !important[^}]*grid-template-rows:var\(--dgo-shell-topbar-h\) minmax\(0,1fr\) var\(--dgo-shell-footer-h\)/s, 'workarea must reserve topbar/main/footer rows');
has(/\.dgo-footer\{[^}]*display:flex !important[^}]*visibility:visible !important/s, 'footer must remain visible and reserved');
has(/\.dgo-main\{[^}]*overflow:hidden !important[^}]*overscroll-behavior:contain/s, 'main must not scroll the page/workspace');
has(/\.split>\*\s*,[\s\S]*?\.pane\{[^}]*overflow:auto !important[^}]*overscroll-behavior:contain/s, 'bounded panes/lists/tables must own scrolling');
console.log('screen-containment-contract passed');
