// Corrected audit P3: dynamic text must not create horizontal overflow or unbounded line growth.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync('styles/app.css','utf8');
assert.match(css,/\.dgo-table th,[\s\S]*?\.alert\{[^}]*overflow-wrap:anywhere/s,'dynamic table/card/dialog text must wrap safely');
assert.match(css,/\.dgo-record-row__main strong,[\s\S]*?\.cc-detail-title\{[^}]*text-overflow:ellipsis/s,'dynamic titles must truncate rather than escape their container');
assert.match(css,/\.dgo-clamp-2,[\s\S]*?\.source-guidance-card p\{[^}]*-webkit-line-clamp:2/s,'two-line clamp utility must exist for dynamic summaries');
assert.match(css,/\.dgo-clamp-3,[\s\S]*?\.module-rule-copy\{[^}]*-webkit-line-clamp:3/s,'three-line clamp utility must exist for operational narrative text');
console.log('dynamic-text-overflow-contract passed');
