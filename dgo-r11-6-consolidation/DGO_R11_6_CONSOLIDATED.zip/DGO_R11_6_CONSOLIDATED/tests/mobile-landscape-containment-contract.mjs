// Mobile landscape containment: topbar and workspace content must not run out of the right side.
import assert from 'node:assert/strict';
import fs from 'node:fs';
const css=fs.readFileSync('styles/app.css','utf8');
assert.match(css,/\.dgo-topbar\{[^}]*overflow:hidden !important/s,'topbar must clip/collapse excess controls instead of overflowing horizontally');
assert.match(css,/@media \(max-width:1180px\)/,'tablet/mobile-landscape topbar media query must exist');
assert.match(css,/\.dgo-search-trigger\{[^}]*flex:0 0 42px/s,'search trigger must collapse at tablet/mobile-landscape widths');
assert.match(css,/@media \(max-width:980px\) and \(orientation:landscape\)/,'mobile landscape media query must exist');
assert.match(css,/--dgo-shell-sidebar-w:224px/,'sidebar must reduce width in mobile landscape');
assert.match(css,/\.toolbar,[\s\S]*?\.action-ribbon\{[^}]*overflow-x:auto !important/s,'wide toolbars/ribbons must scroll internally, not widen the page');
assert.match(css,/\.dgo-toast\{[^}]*max-inline-size:calc\(100vw - 32px\)[^}]*overflow-wrap:anywhere/s,'toast must not overflow the viewport');
console.log('mobile-landscape-containment-contract passed');
