# NITDA Full Deployment Package

This package contains everything needed to deploy the NITDA Task Creation App.

## Files

- index.html
- app-config.js
- README.md

## Lookups

- lookups/categories.json
- lookups/departments.json

## Users

- users/users-page1.json

## How to use

1. Open `app-config.js` and replace:
   - `formFlowUrl` with your Power Automate HTTP POST flow URL (for creating tasks)
   - `docsApiUrl` with your Power Automate HTTP GET flow URL (for listing documents)

2. Host the contents of this package on:
   - SharePoint (as a static HTML page / web part), or
   - Azure Static Web Apps, or
   - Any web server that can serve static files.

3. Open `index.html` in a browser. The app will:
   - Load categories & departments from `lookups/`
   - Lazy-load users from `users/users-page1.json`
   - Call your configured Power Automate flows.
