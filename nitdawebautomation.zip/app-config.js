// app-config.js
// Central place to configure endpoints & paths

const APP_CONFIG = {
  // Power Automate HTTP POST URL for creating tasks
  formFlowUrl: "https://YOUR-TENANT-NAME.logic.azure.com/workflows/YOUR_TASK_FLOW_ID/triggers/manual/paths/invoke?api-version=2016-10-01&sp=...",

  // Power Automate HTTP GET URL for listing documents
  docsApiUrl: "https://YOUR-TENANT-NAME.logic.azure.com/workflows/YOUR_DOCS_FLOW_ID/triggers/manual/paths/invoke?api-version=2016-10-01&sp=...",

  // Lookup and users base paths (relative to index.html)
  lookupsBaseUrl: "./lookups/",
  usersBaseUrl: "./users/"
};
