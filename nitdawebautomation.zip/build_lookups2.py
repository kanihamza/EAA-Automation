import json
from pathlib import Path

BASE = Path(__file__).parent

category_file    = BASE / "Categorymatrix (1).txt"
departments_file = BASE / "Departmentsmatrix.txt"
users_file       = BASE / "Lean Office365Users Details.txt"

with category_file.open(encoding="utf-8") as f:
    cat_raw = json.load(f)

with departments_file.open(encoding="utf-8") as f:
    dept_raw = json.load(f)

with users_file.open(encoding="utf-8") as f:
    users_raw = json.load(f)

def clean(v):
    return v.strip() if isinstance(v, str) else ("" if v is None else str(v))

categories = []
for i, r in enumerate(cat_raw, start=1):
    categories.append({
        "id": f"{clean(r['Category Code'])}-{clean(r['SubCategory Code'])}",
        "category": r["Category"],
        "categoryCode": r["Category Code"],
        "subCategory": r["SubCategory"],
        "subCategoryCode": r["SubCategory Code"],
        "name": f"{r['Category']} - {r['SubCategory']}",
        "defaultPrimaryDSU": r["Default Primary DSU"],
        "defaultSupportingDSU": r["Default Supporting DSU"],
        "informedDSUs": [
            r.get("Informed DSU1"),
            r.get("Informed DSU2"),
            r.get("Informed DSU3")
        ],
        "defaultPriority": r["Priority"]
    })

departments = []
for r in dept_raw:
    departments.append({
        "key": r["Department Key"],
        "name": r["Department"],
        "email": r["Department Email"],
        "headEmail": r["Department Head Email"],
        "headPersonalEmail": r["Department Head Personal Email"],
        "headTitle": r["Department Head Title"]
    })

dept_index = { d["name"].lower(): d["key"] for d in departments }

users = []
for i, u in enumerate(users_raw, start=1):
    dept_key = None
    if isinstance(u.get("department"), str):
        dept_key = dept_index.get(u["department"].lower())
    users.append({
        "id": i,
        "name": u["name"],
        "email": u["email"],
        "departmentName": u["department"],
        "departmentKey": dept_key,
        "jobTitle": u.get("jobTitle")
    })

(BASE / "lookups").mkdir(exist_ok=True)
(BASE / "users").mkdir(exist_ok=True)

(BASE / "lookups" / "categories.json").write_text(
    json.dumps(categories, indent=2, ensure_ascii=False), encoding="utf-8"
)

(BASE / "lookups" / "departments.json").write_text(
    json.dumps(departments, indent=2, ensure_ascii=False), encoding="utf-8"
)

(BASE / "users" / "users-page1.json").write_text(
    json.dumps(users, indent=2, ensure_ascii=False), encoding="utf-8"
)

print("Lookup files generated successfully.")
