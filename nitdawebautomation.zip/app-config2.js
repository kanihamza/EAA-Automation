// app-config.js
// Central place for configuring endpoints and folder paths.

const APP_CONFIG = {

  // Power Automate Flow (POST) — Submit Task
  formFlowUrl:
    "https://YOUR_FLOW_URL_FOR_TASK_SUBMISSION_HERE",

  // Power Automate Flow (GET) — Document List API
  docsApiUrl:
    "https://YOUR_FLOW_URL_FOR_DOCUMENTS_LIST_HERE",

  // Static lookup paths
  lookupsBaseUrl: "./lookups/",
  usersBaseUrl: "./users/"
};
