import json
from pathlib import Path

BASE = Path(__file__).parent

# Input files (your original JSON exports)
category_file    = BASE / "Categorymatrix (1).txt"
departments_file = BASE / "Departmentsmatrix.txt"
users_file       = BASE / "Lean Office365Users Details.txt"

with category_file.open(encoding="utf-8") as f:
    cat_data = json.load(f)

with departments_file.open(encoding="utf-8") as f:
    dept_data = json.load(f)

with users_file.open(encoding="utf-8") as f:
    users_data = json.load(f)

def safe_strip(v):
    return v.strip() if isinstance(v, str) else ("" if v is None else str(v).strip())

def build_categories(cat_data):
    out = []
    for i, row in enumerate(cat_data, start=1):
        cat_code = safe_strip(row.get("Category Code", ""))
        sub_code = safe_strip(row.get("SubCategory Code", ""))

        out.append({
            "id": f"{cat_code}-{sub_code}" if cat_code or sub_code else str(i),
            "category": row.get("Category"),
            "categoryCode": row.get("Category Code"),
            "subCategory": row.get("SubCategory"),
            "subCategoryCode": row.get("SubCategory Code"),
            "name": (
                f"{row.get('Category')} - {row.get('SubCategory')}"
                if row.get("SubCategory") else row.get("Category")
            ),
            "defaultPrimaryDSU": row.get("Default Primary DSU"),
            "defaultSupportingDSU": row.get("Default Supporting DSU"),
            "informedDSUs": [
                row.get("Informed DSU1"),
                row.get("Informed DSU2"),
                row.get("Informed DSU3")
            ],
            "defaultPriority": row.get("Priority")
        })
    return out

def build_depts(dept_data):
    out = []
    for row in dept_data:
        out.append({
            "key": row.get("Department Key"),
            "name": row.get("Department"),
            "email": row.get("Department Email"),
            "headEmail": row.get("Department Head Email"),
            "headPersonalEmail": row.get("Department Head Personal Email"),
            "headTitle": row.get("Department Head Title")
        })
    return out

dept_name_to_key = {
    d["Department"].lower(): d["Department Key"] for d in dept_data
}

def build_users(users_data):
    out = []
    for i, u in enumerate(users_data, start=1):
        dept_name = u.get("department")
        if isinstance(dept_name, str):
            dept_key = dept_name_to_key.get(dept_name.lower())
        else:
            dept_key = None

        out.append({
            "id": i,
            "name": u.get("name"),
            "email": u.get("email"),
            "departmentName": dept_name,
            "departmentKey": dept_key,
            "jobTitle": u.get("jobTitle")
        })
    return out

lookups_dir = BASE / "lookups"
users_dir   = BASE / "users"
lookups_dir.mkdir(exist_ok=True)
users_dir.mkdir(exist_ok=True)

(lookups_dir / "categories.json").write_text(
    json.dumps(build_categories(cat_data), ensure_ascii=False, indent=2),
    encoding="utf-8"
)

(lookups_dir / "departments.json").write_text(
    json.dumps(build_depts(dept_data), ensure_ascii=False, indent=2),
    encoding="utf-8"
)

(users_dir / "users-page1.json").write_text(
    json.dumps(build_users(users_data), ensure_ascii=False, indent=2),
    encoding="utf-8"
)

print("Generated lookups/categories.json, lookups/departments.json, users/users-page1.json")
