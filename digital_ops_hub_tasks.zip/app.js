
/**
 * Digital Operations Hub — Activities Hub (Web)
 * NITDA-branded, Power Automate HTTP integration
 *
 * Mirrors the core interaction patterns from the provided Power Apps screen:
 * - Search, select tasks, bulk re-assign, per-item re-assign
 * - Loading overlay, modal dialog, combo-box style user search
 */

// ======= Configuration =======
const FLOW_URL = '<PASTE_FLOW_HTTP_POST_URL>'; // e.g., https://prod-XX.azurewebsites.net/.../invoke
const API_KEY = '<PASTE_SHARED_SECRET>';       // simple shared secret for request validation in Flow

// ======= App State (Power Apps analogs) =======
let locIsLoading = false;
let locShowBulkAssignDialog = false;
let locBulkAssignUser = null; // { DisplayName, Mail, GivenName }
let locSearchQuery = '';

let colSelectedTasks = []; // array of task records
let colAllTasks = [];      // fetched from Flow: Global Tracking Queue
let colAllUsers = [];      // fetched from Flow: Office 365 Users / Entra

// ======= Utilities =======
const qs = (sel) => document.querySelector(sel);
const qsa = (sel) => Array.from(document.querySelectorAll(sel));

function setLoading(on) {
  locIsLoading = !!on;
  qs('#loadingOverlay').classList.toggle('hidden', !locIsLoading);
}

function formatDate(dstr) {
  if (!dstr) return '';
  const d = new Date(dstr);
  if (Number.isNaN(d.getTime())) return dstr;
  return `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}/${d.getFullYear()}`;
}

function isOverdue(dstr) {
  if (!dstr) return false;
  const d = new Date(dstr);
  const today = new Date();
  // compare date parts only
  d.setHours(0,0,0,0); today.setHours(0,0,0,0);
  return d < today;
}

function updateBulkButtons() {
  const bulkBtn = qs('#btnBulkReAssign');
  const reassignBtn = qs('#btnReAssign');
  const count = colSelectedTasks.length;
  bulkBtn.textContent = `Bulk Re-Assign (${count})`;
  bulkBtn.classList.toggle('hidden', count === 0);
  reassignBtn.disabled = (getLastSelected() == null);
}

function getLastSelected() { return colSelectedTasks[colSelectedTasks.length - 1] || null; }

// ======= Rendering =======
function renderTasks() {
  const list = qs('#tasksList');
  list.innerHTML = '';
  const query = (locSearchQuery || '').toLowerCase();

  const items = colAllTasks.filter(t => {
    if (!query) return true;
    return (String(t.Title||'').toLowerCase().includes(query) || String(t.ID||'').includes(query));
  });

  items.forEach(t => {
    const wrapper = document.createElement('div');
    wrapper.className = 'task-item' + (colSelectedTasks.find(x => x.ID === t.ID) ? ' selected' : '');

    // checkbox
    const cb = document.createElement('input');
    cb.type = 'checkbox'; cb.className = 'checkbox'; cb.checked = !!colSelectedTasks.find(x => x.ID === t.ID);
    cb.addEventListener('change', () => {
      if (cb.checked) {
        if (!colSelectedTasks.find(x => x.ID === t.ID)) colSelectedTasks.push(t);
      } else {
        colSelectedTasks = colSelectedTasks.filter(x => x.ID !== t.ID);
      }
      updateBulkButtons();
      renderTasks();
    });

    // priority bar
    const priorityBar = document.createElement('div');
    priorityBar.className = 'priority-bar ' + ((t.Priority && t.Priority.Value === 'P1 (High)') ? 'priority-high' : 'priority-normal');

    // text block
    const textBlock = document.createElement('div');
    textBlock.className = 'task-text';

    const title = document.createElement('div');
    title.className = 'task-title';
    title.textContent = t.Title || '(Untitled)';

    const assigned = document.createElement('div');
    assigned.className = 'task-meta';
    assigned.textContent = `Assigned To: ${t.AssignedTo || ''}`;

    const due = document.createElement('div');
    due.className = 'task-meta task-due' + (isOverdue(t.DueDate) ? ' overdue' : '');
    due.textContent = `Due: ${formatDate(t.DueDate)}`;

    textBlock.appendChild(title);
    textBlock.appendChild(assigned);
    textBlock.appendChild(due);

    // status
    const status = document.createElement('div');
    status.className = 'task-status';
    status.textContent = (t.Progress && t.Progress.Value) ? t.Progress.Value : '';

    wrapper.appendChild(cb);
    wrapper.appendChild(priorityBar);
    wrapper.appendChild(textBlock);
    wrapper.appendChild(status);

    list.appendChild(wrapper);
  });
}

function openBulkAssign() {
  locShowBulkAssignDialog = true;
  qs('#bulkAssignOverlay').classList.toggle('hidden', !locShowBulkAssignDialog);
  qs('#bulkAssignMsg').textContent = `You are about to re-assign ${colSelectedTasks.length} tasks. Please select the new user.`;
  qs('#btnConfirmBulkAssign').disabled = !locBulkAssignUser;
}

function closeBulkAssign() {
  locShowBulkAssignDialog = false;
  qs('#bulkAssignOverlay').classList.add('hidden');
}

function setBulkAssignUser(u) {
  locBulkAssignUser = u || null;
  qs('#btnConfirmBulkAssign').disabled = !locBulkAssignUser;
}

// ======= Flow Calls =======
async function flowCall(operation, payload = {}) {
  if (!FLOW_URL || FLOW_URL.startsWith('<')) {
    console.warn('FLOW_URL not configured. Skipping network call.');
    return { ok: false, error: 'FLOW_URL not configured.' };
  }
  try {
    const res = await fetch(FLOW_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': API_KEY
      },
      body: JSON.stringify({ operation, payload })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { ok: false, error: data?.error || res.statusText };
    return { ok: true, data };
  } catch (e) {
    console.error(e);
    return { ok: false, error: String(e) };
  }
}

async function fetchTasks() {
  setLoading(true);
  const { ok, data, error } = await flowCall('getTasks');
  setLoading(false);
  if (!ok) {
    console.error('Failed to fetch tasks:', error);
    return;
  }
  // Expect data.tasks: [{ ID, Title, AssignedTo, Priority: {Value}, DueDate, Progress: {Value} }]
  colAllTasks = Array.isArray(data?.tasks) ? data.tasks : [];
  colSelectedTasks = [];
  renderTasks();
  updateBulkButtons();
}

async function fetchUsers(query = '') {
  const { ok, data, error } = await flowCall('getUsers', { query });
  if (!ok) {
    console.error('Failed to fetch users:', error);
    return;
  }
  // Expect data.users: [{ DisplayName, Mail, GivenName }]
  colAllUsers = Array.isArray(data?.users) ? data.users : [];
  renderUsersDropdown();
}

async function bulkReassign() {
  if (!locBulkAssignUser || colSelectedTasks.length === 0) return;
  setLoading(true);
  const taskIds = colSelectedTasks.map(t => t.ID);
  const { ok, data, error } = await flowCall('bulkReassign', { taskIds, newAssignee: locBulkAssignUser });
  setLoading(false);
  closeBulkAssign();
  if (!ok) {
    alert('Bulk re-assign failed: ' + (error || 'Unknown error'));
    return;
  }
  alert(`Bulk re-assign complete. Created ${data?.createdCount || 0} reassignment tasks.`);
  await fetchTasks();
}

// ======= Users ComboBox (client-side filter) =======
function renderUsersDropdown() {
  const box = qs('#usersDropdown');
  box.innerHTML = '';
  colAllUsers.forEach(u => {
    const item = document.createElement('div');
    item.className = 'dropdown-item';
    item.setAttribute('role', 'option');
    item.innerHTML = `<span>${u.DisplayName || ''}</span><span style="color:#666">${u.Mail || ''}</span>`;
    item.addEventListener('click', () => {
      setBulkAssignUser(u);
      // Highlight selection
      qsa('.dropdown-item').forEach(x => x.style.background = '');
      item.style.background = '#e6f2ff';
    });
    box.appendChild(item);
  });
}

// ======= Event Wiring =======
function wireEvents() {
  qs('#searchInput').addEventListener('input', (e) => {
    locSearchQuery = e.target.value || '';
    renderTasks();
  });

  qs('#btnNewAdHocTask').addEventListener('click', () => {
    // Navigate to external terminal / assignment page
    // In Power Apps this was Navigate(EAA_Terminal, ..., { DGOselected: Blank() })
    // Here we link to a placeholder; replace with your URL.
    window.location.href = './eaa-terminal.html';
  });

  qs('#btnBulkReAssign').addEventListener('click', () => {
    openBulkAssign();
    fetchUsers('');
  });

  qs('#btnReAssign').addEventListener('click', () => {
    const one = getLastSelected();
    if (!one) return;
    // In Power Apps: Navigate(EAA_Terminal, ..., { DGOselected: galActivities.Selected })
    // Here we pass a querystring with the selected ID.
    const url = `./eaa-terminal.html?selectedId=${encodeURIComponent(one.ID)}`;
    window.location.href = url;
  });

  qs('#btnCancelBulkAssign').addEventListener('click', () => {
    closeBulkAssign();
  });

  qs('#userSearchInput').addEventListener('input', (e) => {
    const q = (e.target.value || '').trim();
    fetchUsers(q);
  });

  qs('#btnConfirmBulkAssign').addEventListener('click', () => {
    bulkReassign();
  });
}

// ======= Init =======
(function init() {
  wireEvents();
  fetchTasks();
})();
