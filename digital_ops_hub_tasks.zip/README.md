
# Digital Operations Hub — Activities Hub (Web + Power Automate)

A mobile-first, NITDA-branded web interface mirroring the Power Apps _Activities_Hub_ screen. It connects to a single **Power Automate HTTP-triggered flow** to:

- Load tasks from SharePoint (`Global Tracking Queue`)
- Search and select tasks
- Bulk re-assign selected tasks to a new user
- (Optional) open a per-item re-assign terminal page

This package includes:

- `index.html` — the UI
- `styles.css` — NITDA-themed styling
- `app.js` — state management + Flow integration

> Hosting: works on InfinityFree or any static hosting. Just edit configuration in `app.js`.

---

## 1) Configure the Power Automate Flow (HTTP Trigger)

**Connector assumptions:** SharePoint, Office 365 Outlook, Office 365 Users.

### 1.1. Trigger
- **When an HTTP request is received**
- **Request JSON schema** (paste):

```json
{
  "type": "object",
  "properties": {
    "operation": { "type": "string" },
    "payload": { "type": "object" }
  },
  "required": ["operation"]
}
```

> **Security**: Use a shared secret via header `x-api-key`. In the flow, add a **Condition** after the trigger to check `@equals(triggerOutputs()['headers']['x-api-key'], variables('expectedApiKey'))` and respond **401** if false. Store `expectedApiKey` in an environment variable or an **Initialize variable** action.

### 1.2. Variables / Environment
- `expectedApiKey` (String) — same value you’ll put in `app.js`.
- `spSiteUrl` (String) — SharePoint Site URL.
- `spListTasks` (String) — `Global Tracking Queue`.
- `spListComments` (String) — `Task_Comments`.

### 1.3. Switch on `operation`

#### Case: `getTasks`
1. **SharePoint — Get items**
   - Site: `spSiteUrl`
   - List: `spListTasks`
   - Select columns: `ID, Title, AssignedTo, Priority, Progress, DueDate`
2. **Select** (Data Operation) or **Compose** to map each item to:
   ```json
   { "ID": item()?['ID'],
     "Title": item()?['Title'],
     "AssignedTo": item()?['AssignedTo'],
     "Priority": { "Value": item()?['Priority'] },
     "Progress": { "Value": item()?['Progress'] },
     "DueDate": item()?['DueDate'] }
   ```
3. **Response** (200):
   ```json
   { "tasks": <mapped-array> }
   ```
   With headers:
   - `Access-Control-Allow-Origin: *`
   - `Access-Control-Allow-Headers: x-api-key, content-type`

#### Case: `getUsers`
1. **Office 365 Users — Search for users**
   - Search term: `@{coalesce(body('Parse_JSON')?['payload']?['query'],'')}`
   - (Or use **List users** with a top limit and filter later)
2. Map each user to:
   ```json
   { "DisplayName": item()?['DisplayName'],
     "Mail": item()?['Mail'],
     "GivenName": item()?['GivenName'] }
   ```
3. **Response** (200) with `users` array and CORS headers.

#### Case: `bulkReassign`
Input payload:
```json
{ "taskIds": [1,2,3],
  "newAssignee": { "DisplayName": "Name", "Mail": "user@nitda.gov.ng" } }
```

For **each** `taskId`:
1. **Get item** from `spListTasks` by ID → `_oldTask`.
2. **Compose** `_subjectPrefix`:
   - If `lower(newAssignee.Mail) == 'dg@nitda.gov.ng'` then `"🔴 [ACTION] "` else `"🔵 [INFO] "`.
   - Append emoji by `_oldTask['Classification']` using **Switch**:
     - `Events → 📅`, `Engagements → 🤝`, `Reports → 📊`, `Memo → 📑`, `Directives → 📢`, `Projects → 🏗️`, `Security → 🛡️`, `Approval → ✍️`, default `📂`.
3. **Create item** in `spListTasks` (`_newTask`):
   - `Title`: `RE-ASSIGN: ${_oldTask.Title}`
   - `MasterActivity`: `_oldTask.MasterActivity` (copy if same type)
   - `ParentTask`: lookup → `{ Id: _oldTask.ID, Value: _oldTask.Title }`
   - `Progress`: `Pending Acknowledgement`
   - `TaskType`: `_oldTask.TaskType`
   - `AssignedTo`: `newAssignee.Mail`
   - `Priority`: `_oldTask.Priority`
   - `DueDate`: `_oldTask.DueDate`
4. **Create item** in `spListComments`:
   - `TaskLookup`: lookup to `_newTask.ID`
   - `Comment`: HTML rich text:
     ```
     <strong>Task bulk re-assigned</strong> by {approverDisplayName} to {newAssignee.DisplayName}.
     ```
5. **Update item** `_oldTask` → set `Progress = Obsolete (Re-Assigned)`.
6. **Office 365 Outlook — Send an email (V2)** to `newAssignee.Mail`:
   - **Subject**: `@{concat(variables('_subjectPrefix'), ' ', _oldTask.Title, ' (Ref: ', outputs('Create_item')?['body/ID'], ')')}`
   - **HTML body** (match Power Apps message) including link:
     ```html
     <b>You have a new task assignment (re-assigned).</b><br><br>
     <b>Title:</b> @{_oldTask.Title}<br>
     <b>Priority:</b> @{_oldTask.Priority}<br>
     <b>Due Date:</b> @{formatDateTime(_oldTask.DueDate,'dd/MM/yyyy')}<br><br>
     Please click the link below to acknowledge and view details:<br>
     <a href='https://apps.powerapps.com/play/1b402856-92cb-45e8-afbf-f362265afaa1?AssnPID=@{outputs('Create_item')?['body/ID']}'>Open Digital Operations Hub</a>
     ```
   - **Importance**: `High` if `Priority == 'P1 (High)'`, else `Normal`
   - **CC**: `dgsregistry@nitda.gov.ng`
7. After loop, **Response** (200): `{ "createdCount": <number>, "ok": true }` with CORS headers.

> **CORS:** For each Response action, add headers:
> - `Access-Control-Allow-Origin: *`
> - `Access-Control-Allow-Headers: x-api-key, content-type`
> - `Access-Control-Allow-Methods: POST, OPTIONS`

---

## 2) Wire the Web App to the Flow

Open `app.js` and set:
```js
const FLOW_URL = 'https://<your-flow-endpoint-url>'; // from the trigger "HTTP POST URL"
const API_KEY = '<the-same-value-you-check-in-flow>';
```

Deploy the three files (`index.html`, `styles.css`, `app.js`) to your InfinityFree site (e.g., `/htdocs/activities-hub/`).

---

## 3) SharePoint List Columns

**Global Tracking Queue** (key columns used):
- `ID (Number)`
- `Title (Single line)`
- `MasterActivity (Lookup)`
- `ParentTask (Lookup)`
- `Progress (Choice)` — e.g., `Pending Acknowledgement`, `Obsolete (Re-Assigned)`
- `TaskType (Choice)`
- `AssignedTo (Single line)` — email
- `Priority (Choice)` — e.g., `P1 (High)`, `P2 (Normal)`
- `DueDate (Date)`
- `Classification (Single line)` — Events / Reports / etc.

**Task_Comments**:
- `TaskLookup (Lookup)` → Global Tracking Queue ID
- `Comment (Multiple lines, rich text)`

---

## 4) Notes & Parity with Power Apps

- The UI mirrors:
  - Search textbox → `locSearchQuery` filtering `Title` and `Ref ID (ID)`
  - Bulk Re-Assign button shows only when there are selected tasks
  - Per-item Re-Assign navigates to a terminal page with `selectedId`
  - Priority bar colors and overdue due-date styling
- The Flow reproduces the bulk-reassignment logic, including subject prefix emojis and notifications.

---

## 5) Security Hardening (Recommended)

- **Shared secret**: validate `x-api-key` in Flow before any operation.
- **Domain allow-list**: check `Origin` header and only allow your domain.
- **Throttling**: add a concurrency control or queue for bulk operations.
- **Audit**: write an entry to a `Flow_AuditLog` list per request with requester IP and counts.

---

## 6) Troubleshooting

- If you see CORS errors, ensure your Flow `Response` action includes the headers shown above.
- Verify SharePoint column internal names match the ones referenced in actions.
- For user search, ensure Office 365 Users connector has permission to read directory.

---

## 7) License

MIT — Customize as needed for NITDA.
