// Shared assignment payload builder and redaction helpers.
import { AssignmentCascade } from './assignment-cascade.js';
import { normalizePriority } from '../config/priority.config.js';
const EMAIL_RE=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export function splitRecipients(value){ return String(value||'').split(/[;,\s]+/).map(x=>x.trim()).filter(Boolean); }
export function validEmail(value){ return !value || EMAIL_RE.test(String(value).trim()); }
export function validRecipients(values=[]){ return values.every(validEmail); }
function escJson(s){ return String(s).replace(/[&<>]/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[ch])); }
export function redactAssignmentPayload(payload={}){
  const clone=JSON.parse(JSON.stringify(payload));
  const mask=v=>String(v||'').replace(/^(.{2}).*(@.*)?$/,(m,a,b)=>`${a}***${b||''}`);
  for (const key of ['assignedTo','supportingAssignee','createdBy','requestedBy']) if (clone[key]) clone[key]=mask(clone[key]);
  for (const key of ['ccRecipients','copyTo']) if (Array.isArray(clone[key])) clone[key]=clone[key].map(mask);
  if (clone.email?.fromAddress) clone.email.fromAddress=mask(clone.email.fromAddress);
  return clone;
}
const PREVIEW_LABELS={mode:'Assignment type',referenceId:'Reference',category:'Category',subcategory:'Sub-category',dsu:'Primary DSU',assignedTo:'Assigned to',supportDsu:'Support DSU',supportingAssignee:'Co-assignee',priority:'Priority',ack:'Acknowledgement due',due:'Task due',ccCount:'CC recipients'};
export function assignmentPreviewHtml(payload={}){
  const summary=AssignmentCascade.buildPreviewSummary(payload);
  const rows=Object.entries(summary).filter(([,v])=>v!==undefined&&v!==null&&v!=='')
    .map(([k,v])=>`<div class="preview-row"><span class="preview-k">${escJson(PREVIEW_LABELS[k]||k)}</span><span class="preview-v">${escJson(String(v))}</span></div>`).join('');
  return `<div class="assignment-preview"><div class="preview-list">${rows}</div><details class="preview-details"><summary>Technical payload</summary><pre class="preview-box">${escJson(JSON.stringify(redactAssignmentPayload(payload), null, 2))}</pre></details></div>`;
}
function datesValid(p,errors){ if(p.startDate&&p.due&&new Date(p.startDate)>new Date(p.due)) errors.push('start date cannot follow task due date'); if(p.ack&&p.due&&new Date(p.ack)>new Date(p.due)) errors.push('acknowledgement due date cannot follow task due date'); }
export function validateSingleAssignmentPayload(p={}){
  const errors=[]; if (!p.referenceId) errors.push('referenceId is required'); if (!p.category) errors.push('category is required'); if (!p.assignedTo) errors.push('assignedTo is required'); if (p.assignedTo && !validEmail(p.assignedTo)) errors.push('assignedTo must be a valid email'); if (p.supportingAssignee && !validEmail(p.supportingAssignee)) errors.push('supportingAssignee must be a valid email'); if (!validRecipients(p.ccRecipients||[])) errors.push('ccRecipients contains an invalid email'); if (!p.due) errors.push('due date is required'); if (!p.instruction) errors.push('instruction is required'); datesValid(p,errors); return errors;
}
export function buildSingleAssignmentPayload({activity, form, actor}){
  const ccRecipients=splitRecipients(form.copy);
  return {
    schema:'dgo-assignment-payload/v2', source:'single-assignment', assignmentType:form.type||'newassignment', activityId:String(activity.id||''), sourceId:activity.sourceId||'',
    title:activity.title||activity.subject||'Untitled assignment', referenceId:form.referenceId,
    category:form.category||'', categoryCode:form.categoryCode||form.code||'', subcategory:form.subcategory||'', subcategoryCode:form.subcategoryCode||form.sub||'',
    assignedTo:String(form.assignedTo||form.assigned||'').trim(), assignedToDsu:form.dsu||'',
    supportingAssignee:String(form.supportingAssignee||form.support||'').trim(), supportingDsu:form.supportDsu||'', ccRecipients,
    priority:normalizePriority(form.priority||'normal'), startDate:form.startDate||'', ack:form.ack||'', due:form.due||'', instruction:form.comments||'',
    cascadeSnapshot:form.cascadeSnapshot||null, ruleId:form.ruleId||'', cascadeSource:form.cascadeSource||'',
    createdBy:actor?.email||'', createdAt:new Date().toISOString()
  };
}
export function validateBulkAssignmentPayload(p={}){
  const errors=[]; if (!Array.isArray(p.ids) || !p.ids.length) errors.push('at least one activity id is required'); if (!p.category) errors.push('category is required'); if (p.assignedTo && !validEmail(p.assignedTo)) errors.push('assignedTo must be a valid email'); if (p.supportingAssignee && !validEmail(p.supportingAssignee)) errors.push('supportingAssignee must be a valid email'); if (!validRecipients(p.ccRecipients||[])) errors.push('ccRecipients contains an invalid email'); datesValid(p,errors); return errors;
}
export function buildBulkAssignmentPayload({ids, form, actor, otpVerified=false}){
  return { schema:'dgo-bulk-assignment-payload/v2', source:'bulk-assignment', ids, category:form.category||'', categoryCode:form.categoryCode||'', subcategory:form.subcategory||'', subcategoryCode:form.subcategoryCode||'', assignedTo:String(form.assignedTo||form.assigned||'').trim(), assignedToDsu:form.dsu||'', supportingAssignee:String(form.supportingAssignee||form.support||'').trim(), supportingDsu:form.supportDsu||'', ccRecipients:splitRecipients(form.copy), priority:normalizePriority(form.priority||'normal'), startDate:form.startDate||'', ack:form.ack||'', due:form.due||'', instruction:form.comments||'', otpVerified:!!otpVerified, cascadeSnapshot:form.cascadeSnapshot||null, requestedBy:actor?.email||'', requestedAt:new Date().toISOString() };
}
export function buildEmailTaskPayload({email, form, actor, referenceId}){
  return { schema:'dgo-email-task-payload/v2', source:'email-to-task', referenceId, title:form.title||email.subject||'Email task', assignedTo:String(form.assignedTo||actor?.email||'').trim(), category:form.category||'', categoryCode:form.categoryCode||'', subcategory:form.subcategory||'', subcategoryCode:form.subcategoryCode||'', assignedToDsu:form.dsu||'', supportingAssignee:String(form.supportingAssignee||'').trim(), supportingDsu:form.supportDsu||'', priority:normalizePriority(form.priority||'normal'), startDate:form.startDate||'', ack:form.ack||'', due:form.due||'', instruction:form.comments||email.bodyPreview||'', ccRecipients:splitRecipients(form.copy), sourceEmailId:email.id||'', cascadeSnapshot:form.cascadeSnapshot||null, email:{ id:email.id||'', subject:email.subject||'', fromAddress:email.fromAddress||email.from||'', receivedDateTime:email.receivedDateTime||email.received||'', webLink:email.webLink||'' }, createdBy:actor?.email||'', createdAt:new Date().toISOString() };
}
export function validateEmailTaskPayload(p={}){
  const errors=[]; if (!p.referenceId) errors.push('referenceId is required'); if (!p.title) errors.push('title is required'); if (!p.assignedTo) errors.push('assignedTo is required'); if (p.assignedTo && !validEmail(p.assignedTo)) errors.push('assignedTo must be a valid email'); if (p.supportingAssignee && !validEmail(p.supportingAssignee)) errors.push('supportingAssignee must be a valid email'); if (!validRecipients(p.ccRecipients||[])) errors.push('ccRecipients contains an invalid email'); datesValid(p,errors); return errors;
}
