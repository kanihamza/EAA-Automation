# Package Notes — DGO R11.6 Remediated Build

This is the full DGO R11.6 "Obsidian / Figma UI-UX" build with all resolved audit remediations
applied. See `REMEDIATION_REPORT.md` and `AUDIT_CORRECTED.md` (added to this package root).

## Modifications applied (vs. the forensic snapshot)
- `styles/app.css` — micro-typography floor (ministry/grid-label/preview-pill -> 11px) + dynamic-text overflow guards.
- `shared/figma-uiux-runtime.js` — drawer focus-trap + focus-return.

Every other file is byte-identical to the SHA-256-verified snapshot.

## Known reconstruction gap (pre-existing, not caused by remediation)
- `styles/dgo-design-system/fonts/CascadiaMono-Regular.woff2` is **absent**. The binary font was
  not embedded in the source forensic snapshot (no content captured), so it could not be
  reconstructed. It IS referenced by an `@font-face` (`colors_and_type.css:18`) backing
  `"Cascadia Mono"` in `--font-mono`. Because that stack is
  `ui-monospace, "SF Mono", "Cascadia Mono", Menlo, Consolas, monospace` with `font-display:swap`,
  a missing file degrades gracefully to the system monospace stack. Restore the original .woff2
  into `styles/dgo-design-system/fonts/` from your asset source to get exact brand typography.

## Validation
`bash tests/run-all.sh` -> all 7 contract suites pass.
