# DGO R11.6 Obsidian Design System Harmonized

This package integrates the DGO Digital OPS Design System into the governed Obsidian R11.6 runtime.

## Runtime Authority
Obsidian R11.6 remains authoritative for endpoints, RBAC, state schema, module boundaries, action ownership, lifecycle, audit, OTP, idempotency, diagnostics, retention, and reporting.

## Design Authority
The DGO Digital OPS Design System is authoritative for tokens, themes, density, shell, shared components, command palette, accessibility, and responsive behaviour.

## How to Run
Open `index.html` directly in a modern browser or host this folder as static files. No build step is required.

## Supported Execution
- local `file://`
- static hosting
- browser-based operation

## Themes
- light
- dark
- high contrast (`hc`)

## Density
- comfortable
- compact

## Validation
Review `/evidence` for the implementation manifest, responsive certification matrix, accessibility audit matrix, governance regression notes, endpoint immutability report, and checksums.

## Non-Goals
This package does not rotate endpoint URLs, alter Power Automate contracts, change RBAC, replace state schema, or bypass governed actions.

## Native Welcome Experience
Generated: 2026-07-22T11:43:37.860070+00:00

This package includes a first-run, R11.6-native welcome/onboarding overlay. It adapts the boot/progress/orientation ideas from the provided welcome design while preserving the Obsidian shell, router, state, endpoint contracts, RBAC and module boundaries. Replay is available from Settings.

## Acknowledgement / Deep Link Completion
Generated: 2026-07-22T12:02:59.517260+00:00

The acknowledgement feature is fully wired. Deep links using `TaskID`, `taskId`, `ACK` or `AssnPID` route to `#/acknowledgment`, select the target task, build an idempotent acknowledgement payload, update local task state, submit to `SUBSIDIARY_ACTIONS` with `operation: ACKNOWLEDGE`, record receipts, queue failed writes, retry queued acknowledgements and export receipt evidence.

## Acknowledgement User Capture Completion
Generated: 2026-07-22T12:54:35.796738+00:00

Acknowledgements now capture the acknowledging user from the screen, deeplink identity parameters or the current profile, in that order. The payload and receipt ledger include actor name, email, persona, department, phone and capture source.

## Acknowledgement Source-Parity User Guard Completion
Generated: 2026-07-22T13:22:37.776759+00:00

Acknowledgement now enforces the assigned-user-only rule from the attached DeepLink Ack Power Apps screens. The backend payload includes the acknowledging actor, assigned-user metadata, acknowledgement status, task metadata and HTML notification instructions for Registry/assigned-user confirmation.

## Correspondence Email Desk Completion
Generated: 2026-07-22T13:33:43.016961+00:00

This package includes a dedicated `correspondence-email` workspace for outward official correspondence emails, with branded templates, draft/outbox/sent register, EMAIL endpoint dispatch, queued-failure evidence and dispatch register integration. This is separate from acknowledgement/task notification email.

## Figma UI/UX Implementation Completion
Generated: 2026-07-22T13:55:00+01:00

The approved Figma Plan + Build has been implemented as a zero-build DGO R11.6 UI/UX layer. The implementation adds token bridging, responsive/accessibility CSS, shared vanilla component factories, and non-invasive runtime polish while preserving endpoints, RBAC, state, module boundaries, action ownership, audit, pending queue and file:// compatibility.
