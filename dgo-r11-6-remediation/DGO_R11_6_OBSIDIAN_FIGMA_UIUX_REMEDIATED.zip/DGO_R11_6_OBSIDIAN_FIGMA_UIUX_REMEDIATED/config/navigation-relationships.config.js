export const NavigationRelationships = Object.freeze({
  "schema": "dgo-navigation-relationships/v1",
  "primarySidebar": {
    "START_HERE": [
      "home"
    ],
    "OPERATIONS": [
      "correspondence",
      "activities",
      "single-assignment",
      "orchestrator"
    ],
    "CONTROL": [
      "response-tracking",
      "approvals"
    ],
    "CLOSURE": [
      "dispatch",
      "correspondence-email"
    ],
    "SYSTEM": [
      "settings"
    ]
  },
  "hiddenModules": {
    "registry": {
      "ownerWorkspace": "correspondence",
      "entryFrom": [
        "correspondence",
        "activities",
        "lookup"
      ],
      "exitTo": [
        "single-assignment",
        "archive"
      ]
    },
    "bulk-assignment": {
      "ownerWorkspace": "single-assignment",
      "entryFrom": [
        "activities",
        "single-assignment"
      ],
      "exitTo": [
        "orchestrator",
        "response-tracking"
      ]
    },
    "lookup": {
      "ownerWorkspace": "response-tracking",
      "entryFrom": [
        "response-tracking",
        "archive",
        "dispatch",
        "commandPalette"
      ],
      "exitTo": [
        "correspondence",
        "single-assignment",
        "orchestrator",
        "archive"
      ]
    },
    "acknowledgment": {
      "ownerWorkspace": "orchestrator",
      "entryFrom": [
        "orchestrator"
      ],
      "exitTo": [
        "orchestrator"
      ]
    },
    "comments": {
      "ownerWorkspace": "orchestrator",
      "entryFrom": [
        "orchestrator",
        "approvals",
        "dispatch"
      ],
      "exitTo": [
        "previous-module"
      ]
    },
    "fasttrack": {
      "ownerWorkspace": "response-tracking",
      "entryFrom": [
        "home",
        "response-tracking"
      ],
      "exitTo": [
        "single-assignment",
        "orchestrator",
        "response-tracking"
      ]
    },
    "executive": {
      "ownerWorkspace": "approvals",
      "entryFrom": [
        "approvals",
        "response-tracking"
      ],
      "exitTo": [
        "approvals",
        "dispatch"
      ]
    },
    "archive": {
      "ownerWorkspace": "dispatch",
      "entryFrom": [
        "dispatch",
        "registry",
        "lookup"
      ],
      "exitTo": [
        "lookup",
        "reports"
      ]
    },
    "reports": {
      "ownerWorkspace": "response-tracking",
      "entryFrom": [
        "response-tracking",
        "archive"
      ],
      "exitTo": [
        "response-tracking",
        "statistics"
      ]
    },
    "statistics": {
      "ownerWorkspace": "response-tracking",
      "entryFrom": [
        "response-tracking",
        "reports",
        "home"
      ],
      "exitTo": [
        "response-tracking",
        "reports"
      ]
    },
    "assistant": {
      "ownerWorkspace": "home",
      "entryFrom": [
        "anyModule"
      ],
      "exitTo": [
        "previous-module"
      ]
    },
    "operator-hud": {
      "ownerWorkspace": "settings",
      "entryFrom": [
        "settings",
        "diagnostics"
      ],
      "exitTo": [
        "settings",
        "diagnostics"
      ]
    },
    "diagnostics": {
      "ownerWorkspace": "settings",
      "entryFrom": [
        "settings",
        "operator-hud"
      ],
      "exitTo": [
        "settings",
        "operator-hud"
      ]
    },
    "user-admin": {
      "ownerWorkspace": "settings",
      "entryFrom": [
        "settings"
      ],
      "exitTo": [
        "settings",
        "diagnostics"
      ]
    }
  },
  "legacyScreenRouteMap": {
    "screen-home": "home",
    "home": "home",
    "screen-docs": "activities",
    "docs": "activities",
    "documents": "activities",
    "screenActivities": "activities",
    "Activities": "activities",
    "screen-assign": "single-assignment",
    "screenAssign": "single-assignment",
    "assign": "single-assignment",
    "screen-bulk-assign": "bulk-assignment",
    "bulkAssign": "bulk-assignment",
    "bulk-assignment": "bulk-assignment",
    "screen-tasks": "orchestrator",
    "tasks": "orchestrator",
    "screenTasks": "orchestrator",
    "screen-emails": "correspondence",
    "emails": "correspondence",
    "screenEmails": "correspondence",
    "screen-response-track": "response-tracking",
    "response-track": "response-tracking",
    "responseTrack": "response-tracking",
    "screenSettings": "settings",
    "screen-settings": "settings",
    "settings": "settings",
    "telemetry": "operator-hud",
    "diagnostics": "diagnostics"
  }
});
