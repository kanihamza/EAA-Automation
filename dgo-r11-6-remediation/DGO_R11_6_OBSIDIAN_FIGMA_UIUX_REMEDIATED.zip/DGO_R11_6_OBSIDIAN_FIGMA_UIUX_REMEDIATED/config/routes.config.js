export const Routes = [
  {
    "path": "home",
    "label": "Command Center",
    "group": "START HERE",
    "kind": "dashboard",
    "kpi": true
  },
  {
    "path": "activities",
    "label": "Activities",
    "group": "OPERATIONS",
    "kind": "dashboard",
    "kpi": true
  },
  {
    "path": "correspondence",
    "label": "Intake & Assignment",
    "group": "OPERATIONS",
    "kind": "workspace",
    "kpi": true
  },
  {
    "path": "response-tracking",
    "label": "Tracking & Monitoring",
    "group": "CONTROL",
    "kind": "workspace",
    "kpi": false
  },
  {
    "path": "orchestrator",
    "label": "My Work / Departmental Work",
    "group": "OPERATIONS",
    "kind": "workspace",
    "kpi": false
  },
  {
    "path": "single-assignment",
    "label": "Assignment Desk",
    "group": "OPERATIONS",
    "kind": "form",
    "kpi": false
  },
  {
    "path": "bulk-assignment",
    "label": "Bulk Assignment",
    "group": "OPERATIONS",
    "kind": "form",
    "kpi": false
  },
  {
    "path": "fasttrack",
    "label": "FastTrack SLA",
    "group": "CONTROL",
    "kind": "dashboard",
    "kpi": true
  },
  {
    "path": "approvals",
    "label": "Review & Approval",
    "group": "CONTROL",
    "kind": "workspace",
    "kpi": false
  },
  {
    "path": "acknowledgment",
    "label": "Acknowledgment Queue",
    "group": "OPERATIONS",
    "kind": "workspace",
    "kpi": false
  },
  {
    "path": "dispatch",
    "label": "Dispatch & Archive",
    "group": "CLOSURE",
    "kind": "workspace",
    "kpi": false
  },
  {
    "path": "registry",
    "label": "Registry",
    "group": "OPERATIONS",
    "kind": "workspace",
    "kpi": true
  },
  {
    "path": "comments",
    "label": "Comments",
    "group": "OPERATIONS",
    "kind": "workspace",
    "kpi": false
  },
  {
    "path": "reports",
    "label": "Reports",
    "group": "CONTROL",
    "kind": "workspace",
    "kpi": false
  },
  {
    "path": "statistics",
    "label": "Statistics",
    "group": "CONTROL",
    "kind": "dashboard",
    "kpi": true
  },
  {
    "path": "executive",
    "label": "Executive Dashboard",
    "group": "CONTROL",
    "kind": "dashboard",
    "kpi": true
  },
  {
    "path": "assistant",
    "label": "Assistant",
    "group": "SYSTEM",
    "kind": "workspace",
    "kpi": false
  },
  {
    "path": "lookup",
    "label": "Lookup",
    "group": "OPERATIONS",
    "kind": "workspace",
    "kpi": false
  },
  {
    "path": "operator-hud",
    "label": "Operator HUD",
    "group": "SYSTEM",
    "kind": "dashboard",
    "kpi": true
  },
  {
    "path": "settings",
    "label": "Administration",
    "group": "SYSTEM",
    "kind": "admin",
    "kpi": false
  },
  {
    "path": "diagnostics",
    "label": "Diagnostics",
    "group": "SYSTEM",
    "kind": "dashboard",
    "kpi": true
  },
  {
    "path": "user-admin",
    "label": "User Administration",
    "group": "SYSTEM",
    "kind": "admin",
    "kpi": false
  },
  {
    "path": "archive",
    "label": "Archive",
    "group": "CLOSURE",
    "kind": "workspace",
    "kpi": true
  },
  {
    "path": "correspondence-email",
    "label": "Email Desk",
    "group": "CLOSURE",
    "kind": "workspace",
    "kpi": true
  }
];
