# State Schema Regression Report

`config/state-schema.config.js` is preserved unchanged. `core/state.js` was only adjusted to default the UI theme to `light`.
