# Acknowledgement User Capture Completion Report

Generated: 2026-07-22T12:54:35.796738+00:00

## Issue Resolved
The acknowledgement process previously relied mostly on `State.profile` for the actor and did not comprehensively capture the acknowledging user from acknowledgement links or the acknowledgement screen.

## Implemented
- Deeplink preservation expanded to include actor identity fields: `actorEmail`, `actorName`, `userEmail`, `userName`, `staffEmail`, `displayName`, `persona`, `role`, `department`, `unit`, and `phone`.
- `core/acknowledgement-service.js` now resolves the actor from form input first, then deeplink context, then state profile.
- Acknowledgement payload now includes `actor`, `actorName`, `actorEmail`, `actorPersona`, `actorDepartment`, `actorPhone`, and `actorCapturedFrom`.
- Idempotency key now includes the resolved actor email so user-specific acknowledgement submissions are traceable.
- `modules/acknowledgment.js` now renders an **Acknowledging User** form and submits those values with the acknowledgement.
- Receipt ledger now stores and exports `actorName` and `actorCapturedFrom` in addition to `actorEmail`.

## User Capture Precedence
1. User values entered/confirmed in the acknowledgement screen.
2. Deeplink identity parameters.
3. Current R11.6 `State.profile`.

## Status
Complete. No pending acknowledgement user-capture items remain.
