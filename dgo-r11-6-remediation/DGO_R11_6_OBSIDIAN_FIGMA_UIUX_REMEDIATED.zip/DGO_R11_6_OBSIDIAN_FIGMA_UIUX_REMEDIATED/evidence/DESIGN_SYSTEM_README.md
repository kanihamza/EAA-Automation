# DGO Digital OPS — Design-System Reference Package

**Primary deliverable:** `DGO Digital OPS.dc.html` (opens in a browser; also runs live in the project). A NITDA-branded, responsive, accessible reference implementation of the DGO Digital OPS platform across its lifecycle spine, with light/dark/high-contrast themes, a command palette, persona switching, and a master-detail pane.

**This package contains**
- `DGO Digital OPS.dc.html` — reference source of record (SHA-256 in the checksum file)
- `DESIGN_SYSTEM_IMPLEMENTATION_REPORT.md`
- `DESIGN_SYSTEM_IMPLEMENTATION_TRACE.json`
- `DESIGN_TOKEN_MAP.json`
- `COMPONENT_COVERAGE_MATRIX.json`
- `RESPONSIVE_BEHAVIOUR_MATRIX.json`
- `ACCESSIBILITY_UI_CONTRACT_MATRIX.json`
- `DESIGN_SYSTEM_AUDIT_MATRIX.json` / `.md`
- `DGO_R11_6_OBSIDIAN_DESIGN_SYSTEM_REFERENCE.sha256.txt` — real SHA-256 for each file

**Honest caveats**
- This is a **design reference**, not a rebuilt runtime. The 118-file forensic runtime was not modified.
- `bash tests/run-all.sh` was **not** run here; no validation pass is claimed. Run it on your side.
- The copy of the `.dc.html` here references the bound design-system token files by relative path; the runnable copy lives at the project root.
