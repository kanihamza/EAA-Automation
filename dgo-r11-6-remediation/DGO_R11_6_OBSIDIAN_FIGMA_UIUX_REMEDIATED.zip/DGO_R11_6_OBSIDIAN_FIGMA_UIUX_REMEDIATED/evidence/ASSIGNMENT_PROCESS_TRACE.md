# Assignment Process — End-to-End Trace, Anomaly & Efficiency Review

Traced every step, component and data provision in the assignment workflow from source selection to backend sync, and verified it live. **No functional anomalies.** Two real seamlessness/efficiency defects were found and **fixed**.

## 1. Data provisioning (inputs the process depends on)
| Provision | Source | Consumed by |
|---|---|---|
| **Categories** (Category, Codes, Default Primary/Support DSU, INFORMDSU1-3, Priority, Timeline) | `FETCH_ALL`/`REFERENCE_DATA` → `data-loader` → `normalizeCategory` → `state.categories` | cascade `matrix()` → category/subcategory options, rule matching |
| **Departments** (DSU_KEY, DSU_HeadEmail, DSU_HeadPersonalEmail, DSU_HeadTitle) | same → `normalizeDepartment` → `state.departments` | cascade `departments()` → assignee, co-assignee, CC, titles |
| **Users** (794) | same → `normalizeUser` → `state.users` | assignee/CC datalist, `usersForDsu()` |
| **Fallback matrix** | `assignment-cascade.config.js` | `seedFallbackIfEmpty()` — seeds categories only when the backend hasn't loaded (graceful default) |
| **Endpoint contracts** | `endpoints.config.js` — `SINGLE_ASSIGNMENT`, `BULK_ASSIGNMENT` (real Power Automate URLs) | governed `invoke()` |
| **Governance config** | `action-ownership.config.js` (`assign-one → owner:single-assignment, audit:audit:assigned, backend:SINGLE_ASSIGNMENT`), `priority.config.js` | ownership assertion + audit + priority normalization |

## 2. Entry points (all converge on one governed form)
- **Intake & Assignment** (correspondence) → select record → **Assign** → `mountAssignmentForm(host, item, {guidance:false})` inline.
- **Assignment Desk** (`single-assignment` route) → `mountAssignmentForm(host, activity, {guidance:true})`.
- **Bulk Assignment** (`bulk-assignment`) → `buildBulkAssignmentPayload` → `BULK_ASSIGNMENT`.
- Email-to-task and Executive routing reuse the same payload/cascade contracts.

## 3. Cascade engine (`core/assignment-cascade.js`)
`cascade({activity, draft, state, changed})` →
1. Clears downstream fields for the changed key (`CASCADE_DOWNSTREAM` map) so they recompute.
2. `bestRule()` matches category → subcategory → DSU against `matrix()`.
3. Derives: Primary DSU, **Assignee** (dept head email), **Assignee Title** (`DSU_HeadTitle`), Support DSU + Co-Assignee, **CC** (INFORMDSU1-3 → dept personal emails), Priority, Start/Ack/Due dates, Instruction template.
4. Explicit DSU choice overrides the rule's assignee (`dsuOverridesRule`); manual edits are preserved.
Local draft autosave via `localStorage` (`saveDraft`/`loadDraft`/`clearDraft`).

## 4. Governed submit pipeline (`mountAssignmentForm.onsubmit`)
```
collect() → validateDraft() [cascade rules]  ──fail→ toast, stop
→ makeRef() if no reference
→ cascade('submit') snapshot
→ buildSingleAssignmentPayload() → validateSingleAssignmentPayload() [email/date/required]  ──fail→ toast, stop
→ confirmAction(preview)  [redacted PII preview]  ──cancel→ stop
→ executeOwnedAction('single-assignment','assign-one', runner):
     assertModuleAction()           [ownership gate]
     audit 'started'
     runner:
        createTask()  → task (uuid, ref, assignee, dates, priority)
        State.patch({ activities:Treated/Assigned, tracking:[task,...], correspondence:Delegated, audit })
        invoke('SINGLE_ASSIGNMENT', {...}).catch → offline queue + toast
     audit 'completed'
→ clearDraft() → toast 'Assignment created' → onDone()/route
```
Two validation layers, ownership assertion, full audit lifecycle, redacted preview, and graceful offline-queue on backend failure — **no dead ends, no ungoverned path.**

## 5. Downstream fan-out (verified live)
Task → **tracking** (Response Tracking / My Work / Orchestrator); correspondence → **Delegated/Assigned**; activity → **Treated**; **audit** ledger entries at start+complete; backend → `SINGLE_ASSIGNMENT` (or queued). Live check: tasks **5 → 6**, correspondence delegated, audit recorded, assignee `dg.head@nitda.gov.ng`, **0 errors.**

## 6. Anomaly & bottleneck review
**Functional anomalies: none.** Every leg resolves, both validation gates fire, governance + audit + backend contract all present and correct.

**Efficiency / seamlessness defects found → FIXED:**
| Defect | Measured (before) | Cause | Fix | Measured (after) |
|---|---|---|---|---|
| Perceptible lag on every dropdown change | full-form rebuild per change (incl. 794-row user datalist) + a redundant second cascade | `apply()` called `mountAssignmentForm()` (full re-mount) | `apply()` now updates **in place** — field values + subcategory options + summary only | synchronous apply **~9 ms avg**; user datalist no longer rebuilt (stable 794→794) |
| **Keyboard focus lost** on every change (`activeElement → BODY`) | full DOM teardown destroyed the focused control | same | in-place update keeps the control in the DOM | focus **retained** (`dsu → dsu`) |

Residual (minor, non-blocking, left as-is): draft autosave writes `localStorage` on each keystroke — negligible cost, no perceptible impact.

## 7. Verification
- Bundled tests `run-all.sh` → RC 0 (incl. `cascade-downstream` + `cascade-summary` contracts — cascade logic unchanged/correct).
- Full route sweep: 24/24 render, **0 runtime errors**; Assignment Desk + inline + summary all render.
- End-to-end assignment at 794-user scale: task created, correspondence delegated, audit written, correct cascade-derived assignee/title/CC.

## Files changed
`modules/single-assignment.js` — `apply()` converted from full re-mount to targeted in-place update (adds `renderSummary` helper). No cascade, payload, governance, or backend change.
