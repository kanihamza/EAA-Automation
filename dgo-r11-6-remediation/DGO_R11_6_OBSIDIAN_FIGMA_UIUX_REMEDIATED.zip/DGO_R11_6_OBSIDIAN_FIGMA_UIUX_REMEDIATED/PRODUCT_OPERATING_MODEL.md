# PRODUCT_OPERATING_MODEL — DGO Digital OPS

Generated: 2026-07-20T21:44:26.927768+00:00

## Operating Model

The platform is operated as a DGCEO-led lifecycle system, not as disconnected technical modules. Every record enters through one of four ingestion sources and moves through a controlled lifecycle: ingest, registry/minutes, classification, assignment, work execution, tracking, review, dispatch, closure and archive.

## Visible Workspaces

### Command Center
- Route: `home`
- Purpose: Single DGCEO operational control point showing matters, risks and next actions across all sources.

### Intake & Registry
- Route: `correspondence`
- Purpose: Capture, register, classify and minute all matters from the four ingestion sources.

### Assignment Desk
- Route: `single-assignment`
- Purpose: Create governed tasks from documents, emails, portal submissions and DGCEO outgoing correspondence.

### My Work / Departmental Work
- Route: `orchestrator`
- Purpose: Allow Departments, Units, Service Points and Staff to act on assigned tasks.

### Tracking & Monitoring
- Route: `response-tracking`
- Purpose: Track end-to-end lifecycle, SLA, response evidence, ageing and matched matters.

### Review & Approval
- Route: `approvals`
- Purpose: Support formal review, return, reject, approval and DGCEO/executive decision trace.

### Dispatch & Archive
- Route: `dispatch`
- Purpose: Send/no-dispatch, capture receipt, close and archive the operational record.

### Administration
- Route: `settings`
- Purpose: Manage users, roles, endpoints, diagnostics, configuration and system health.

## Rule

Technical modules may exist internally, but users should be guided through outcome-led workspaces. Mutating actions must be owned by the correct workspace and protected by preview, confirmation and audit.
