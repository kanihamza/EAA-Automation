// Cascade must derive the Assignment-Summary fields the way the reference Power Automate cascade does:
//  - Assignee Title from the primary department's DSU_HeadTitle
//  - CC recipients from INFORMDSU1/2/3 resolved to each department head's (personal) email
//  - Support DSU / co-assignee from Default Supporting Department/Unit
// Uses the reference's exact SharePoint/Power-Automate column names.
import assert from 'node:assert/strict';
globalThis.localStorage={store:{},getItem(k){return this.store[k]||null},setItem(k,v){this.store[k]=v},removeItem(k){delete this.store[k]}};
const { AssignmentCascade } = await import('../core/assignment-cascade.js');
const state={
  categories:[{
    Category:'Executive Correspondence', 'Category Code':'EXC', Subcategory:'DG Attention', 'SubCategory Code':'DG',
    'Default Primary Responsible':'DSU-ODG', 'Default Supporting Department/Unit':'DSU-REG',
    INFORMDSU1:'DSU-LEG', INFORMDSU2:'DSU-ICT', Priority:'high'
  }],
  departments:[
    {DSU_KEY:'DSU-ODG', Title:'Office of the DG', DSU_HeadEmail:'dg.head@nitda.gov.ng', DSU_HeadPersonalEmail:'dg.personal@nitda.gov.ng', DSU_HeadTitle:'Director-General'},
    {DSU_KEY:'DSU-REG', Title:'Registry', DSU_HeadEmail:'reg.head@nitda.gov.ng', DSU_HeadTitle:'Head, Registry'},
    {DSU_KEY:'DSU-LEG', Title:'Legal', DSU_HeadEmail:'leg.head@nitda.gov.ng', DSU_HeadPersonalEmail:'leg.personal@nitda.gov.ng', DSU_HeadTitle:'Director, Legal'},
    {DSU_KEY:'DSU-ICT', Title:'ICT', DSU_HeadEmail:'ict.head@nitda.gov.ng', DSU_HeadPersonalEmail:'ict.personal@nitda.gov.ng', DSU_HeadTitle:'Director, ICT'}
  ], users:[]
};
const a={id:'e1', title:'Executive memo', referenceId:'R-EXC-1'};
let d=AssignmentCascade.cascade({activity:a, draft:{}, state, changed:'initial'});
d=AssignmentCascade.cascade({activity:a, draft:{...d, category:'Executive Correspondence'}, state, changed:'category'});

assert.equal(d.dsu,'DSU-ODG','primary DSU from Default Primary Responsible');
assert.equal(d.assignedTo,'dg.head@nitda.gov.ng','assignee from primary department head email');
assert.equal(d.assigneeTitle,'Director-General','assignee title from DSU_HeadTitle');
assert.equal(d.supportDsu,'DSU-REG','support DSU from Default Supporting Department/Unit');
assert.equal(d.supportingAssignee,'reg.head@nitda.gov.ng','co-assignee from support department head');
// CC = INFORMDSU1/2/3 resolved to each dept head's personal email (falls back to head email).
const cc=d.copy.split(/[;,]+/).map(x=>x.trim()).filter(Boolean);
assert.deepEqual(cc,['leg.personal@nitda.gov.ng','ict.personal@nitda.gov.ng'],'CC from INFORMDSU personal emails');

// Changing the primary DSU must re-derive both assignee AND assignee title.
d=AssignmentCascade.cascade({activity:a, draft:{...d, dsu:'DSU-ICT'}, state, changed:'dsu'});
assert.equal(d.assignedTo,'ict.head@nitda.gov.ng','DSU change re-derives assignee');
assert.equal(d.assigneeTitle,'Director, ICT','DSU change re-derives assignee title');

console.log('cascade-summary-contract passed');
