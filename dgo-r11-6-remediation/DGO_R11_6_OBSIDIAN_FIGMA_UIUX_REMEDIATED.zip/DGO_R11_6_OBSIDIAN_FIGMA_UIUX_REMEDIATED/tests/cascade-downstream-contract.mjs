// Cascade must recompute downstream fields when an upstream dropdown changes:
// category change -> subcategory/dsu/assignee recompute; DSU change -> assignee recomputes;
// manual edits are preserved.
import assert from 'node:assert/strict';
globalThis.localStorage={store:{},getItem(k){return this.store[k]||null},setItem(k,v){this.store[k]=v},removeItem(k){delete this.store[k]}};
const { AssignmentCascade } = await import('../core/assignment-cascade.js');
const state={categories:[
 {category:'Correspondence',categoryCode:'CR',subcategory:'Inbound',subcategoryCode:'IN',dsuKey:'DSU-ICT',assignedTo:'ict.head@x'},
 {category:'Procurement',categoryCode:'PR',subcategory:'Tender',subcategoryCode:'TN',dsuKey:'DSU-PROC',assignedTo:'proc.head@x'}],
 departments:[{dsuKey:'DSU-ICT',title:'ICT',headEmail:'ict.head@x'},{dsuKey:'DSU-REG',title:'Registry',headEmail:'reg.head@x'},{dsuKey:'DSU-PROC',title:'Procurement',headEmail:'proc.head@x'}],users:[]};
const a={id:'x1',title:'T',referenceId:'R1'};
let d=AssignmentCascade.cascade({activity:a,draft:{},state,changed:'initial'});
d=AssignmentCascade.cascade({activity:a,draft:{...d,category:'Procurement'},state,changed:'category'});
assert.equal(d.dsu,'DSU-PROC','category change must recompute DSU'); assert.equal(d.assignedTo,'proc.head@x','category change must recompute assignee');
d=AssignmentCascade.cascade({activity:a,draft:{...d,dsu:'DSU-REG'},state,changed:'dsu'});
assert.equal(d.dsu,'DSU-REG','DSU choice must be preserved'); assert.equal(d.assignedTo,'reg.head@x','DSU change must recompute assignee');
d=AssignmentCascade.cascade({activity:a,draft:{...d,assignedTo:'manual@x'},state,changed:'manual'});
assert.equal(d.assignedTo,'manual@x','manual edit must be preserved');
console.log('cascade-downstream-contract passed');
