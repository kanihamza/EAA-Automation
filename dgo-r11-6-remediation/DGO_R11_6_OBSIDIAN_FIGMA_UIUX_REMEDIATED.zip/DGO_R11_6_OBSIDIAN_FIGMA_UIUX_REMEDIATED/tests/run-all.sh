#!/usr/bin/env bash
set -e
# Rigorous ESM syntax check across all app JS (forced module parse).
for f in $(find config core modules shared -name '*.js'); do node --input-type=module --check < "$f" || { echo "SYNTAX FAIL: $f"; exit 1; }; done
echo "syntax-integrity passed"
for f in tests/*.mjs; do node "$f"; done
