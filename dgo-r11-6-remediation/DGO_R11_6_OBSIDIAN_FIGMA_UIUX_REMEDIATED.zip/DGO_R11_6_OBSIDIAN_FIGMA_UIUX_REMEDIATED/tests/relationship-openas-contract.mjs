// Regression: relationship-runtime must honor action-routing `openAs`.
// Before the fix, runRoutedAction navigated whenever `navigateTo` was set (always),
// so detail-pane/modal/drawer actions wrongly full-jumped (drawer->assistant,
// detail-pane->lookup). resolveRoutedDestination encodes the corrected decision.
import assert from 'node:assert/strict';
import { resolveRoutedDestination } from '../shared/relationship-runtime.js';
import { ActionRouting } from '../config/action-routing.config.js';

// full-route navigates to navigateTo
assert.equal(resolveRoutedDestination({openAs:'full-route',navigateTo:'single-assignment',sourceModule:'activities'}), 'single-assignment');
// in-place surfaces stay put (null)
for(const openAs of ['detail-pane','modal','drawer']){
  assert.equal(resolveRoutedDestination({openAs,navigateTo:'lookup',sourceModule:'activities'}), null, `${openAs} must not navigate`);
}
// same-page that stays in source module -> no navigation
assert.equal(resolveRoutedDestination({openAs:'same-page',navigateTo:'activities',postSuccess:'activities',sourceModule:'activities'}), null);
// same-page workflow progression to another module (submit -> orchestrator) navigates
assert.equal(resolveRoutedDestination({openAs:'same-page',postSuccess:'orchestrator',sourceModule:'single-assignment'}), 'orchestrator');

// Real-config invariants: every drawer/detail-pane/modal action stays in place.
let inPlace=0, fullRoute=0;
for(const a of ActionRouting.actions){
  const dest=resolveRoutedDestination(a);
  if(['detail-pane','modal','drawer'].includes(a.openAs)){ assert.equal(dest,null,`${a.id} (${a.openAs}) must stay in place`); inPlace++; }
  if(a.openAs==='full-route'){ assert.ok(dest,`${a.id} (full-route) must resolve a destination`); fullRoute++; }
}
assert.ok(inPlace>=3 && fullRoute>=3, 'expected several in-place and full-route actions in config');
console.log(`relationship-openas-contract passed (in-place:${inPlace}, full-route:${fullRoute})`);
