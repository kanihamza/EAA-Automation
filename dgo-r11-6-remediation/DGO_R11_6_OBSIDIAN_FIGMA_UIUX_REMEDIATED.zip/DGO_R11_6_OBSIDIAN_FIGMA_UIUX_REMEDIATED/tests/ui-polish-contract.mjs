// Interface polish: toolbar must wrap (search never collapses) and tables must not be
// forced wider than a typical full-width workspace panel.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const css=fs.readFileSync('styles/app.css','utf8');
const tb=css.match(/\.toolbar\{[^}]*\}/); assert.ok(tb);
assert.match(tb[0],/flex-wrap:wrap/,'.toolbar must wrap');
const tbi=css.match(/\.toolbar input\{[^}]*\}/); assert.ok(tbi);
assert.match(tbi[0],/min-width:2\d\dpx|min-width:1[5-9]\dpx/,'.toolbar input must keep a usable min-width');
assert.doesNotMatch(tbi[0],/min-width:0(?![.\d])/,'.toolbar input must not collapse to 0');
const tw=css.match(/\.tablewrap table\{[^}]*\}/); assert.ok(tw);
const mw=+(tw[0].match(/min-width:(\d+)px/)||[])[1];
assert.ok(mw && mw<=600,`table min-width must be <=600px so full-width tables do not clip (got ${mw})`);
assert.match(css,/\.tablewrap[^{]*::-webkit-scrollbar/,'tables must have a visible scrollbar affordance');
console.log('ui-polish-contract passed');
