// Locks in the Correspondence/Registry disambiguation + the Intake↔Assignment merge.
import assert from 'node:assert/strict'; import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');

// 1. No stale collision labels anywhere.
for(const f of ['config/routes.config.js','config/workflow-clarity.config.js','config/source-views.config.js','config/product-operating-model.config.js']){
  assert.ok(!read(f).includes('Intake & Registry'), `${f} must not use "Intake & Registry"`);
}
// 2. Merged workspace: correspondence route is labelled "Intake & Assignment" (sidebar + card + header).
assert.match(read('config/routes.config.js'),/"path":\s*"correspondence"[\s\S]*?"label":\s*"Intake & Assignment"/,'routes.config correspondence label must be "Intake & Assignment"');
assert.match(read('config/workflow-clarity.config.js'),/"route":\s*"correspondence"[\s\S]*?"label":\s*"Intake & Assignment"/,'workflow-clarity intake label must be "Intake & Assignment"');
// The workspace is identified by the top-bar route label (asserted above); the redundant in-page
// intro header is removed, and the merged workspace now renders its condensed control strip.
assert.match(read('modules/correspondence.js'),/class="cc-controlbar"/,'merged Intake & Assignment workspace must render the condensed control strip');

// 3. Assignment Desk is no longer a primary (visible) workspace, but the route still exists.
assert.ok(!/"route":\s*"single-assignment"[\s\S]{0,120}"label":\s*"Assignment Desk"[\s\S]{0,200}"group"/.test(read('config/workflow-clarity.config.js')),'single-assignment must be removed from VisibleWorkspaces');
assert.match(read('config/workflow-clarity.config.js'),/"single-assignment":\s*\{[\s\S]*?visibleThrough/,'single-assignment must be a guided-internal route');
assert.match(read('config/routes.config.js'),/"path":\s*"single-assignment"/,'single-assignment route must still be registered (reassign/deeplinks)');

// 4. Assign-in-place: correspondence imports + renders the shared assignment form inline; no more navigate-away button.
const corr=read('modules/correspondence.js');
assert.match(corr,/import\s*\{\s*mountAssignmentForm\s*\}\s*from\s*'\.\/single-assignment\.js'/,'correspondence must import mountAssignmentForm');
assert.match(corr,/data-assign-toggle/,'correspondence must have an inline Assign toggle');
assert.match(corr,/data-assign-host/,'correspondence must host the inline assignment form');
assert.match(corr,/mountAssignmentForm\(assignHost/,'correspondence must mount the assignment form inline');
assert.ok(!/data-to-assignment|Send to Assignment/.test(corr),'old navigate-away "Send to Assignment" must be gone');
assert.match(corr,/data-to-registry>Send to Registry</,'Send to Registry handoff remains');

// 5. Shared assignment form is exported and reused (single source of truth).
const sa=read('modules/single-assignment.js');
assert.match(sa,/export function mountAssignmentForm\(/,'single-assignment must export mountAssignmentForm');
assert.match(sa,/patch\.correspondence\s*=/,'assignment submit must also update the correspondence source record');

// 6. Registry remains the single home of registration.
assert.match(read('modules/registry.js'),/Register selected correspondence/,'registry keeps registration');
assert.ok(!/Register selected correspondence/.test(corr),'correspondence must not duplicate registration');

// 7. routes.config uses one canonical group taxonomy.
const groups=new Set([...read('config/routes.config.js').matchAll(/"group":\s*"([^"]+)"/g)].map(m=>m[1]));
assert.deepEqual([...groups].sort(),['CLOSURE','CONTROL','OPERATIONS','START HERE','SYSTEM']);
console.log('module-clarity-contract passed');
