DGCEO Deploy-Ready (RBAC Edition)
================================

WHAT THIS ADDS
--------------
1) Role-based UX enforcement (DG / DSU / Admin):
   - Capability-based button visibility
   - DSU scoping (client-side filter) for Tasks using assignedUserDsuKey
   - Role persistence in localStorage

IMPORTANT SECURITY NOTE
-----------------------
This RBAC is a UX control. You MUST enforce the same constraints server-side
in Power Automate flows (recommended) to prevent bypass.

FILES
-----
index.html
labels.json
adapter-mapping-config.json
labels-helper.js
domain-validator.js
role-helper.js
role-config.json

CONFIGURE
---------
In index.html set FLOW_ENDPOINTS:
- ListDocuments
- ListTasks
- ListEmails
- ReloadAllCounts
- CreateTask
- UpdateTaskProgress
- AddTaskComment
- GetSystemTelemetry
- GetUserRole (optional)

ROLE MODES
----------
Manual mode: choose role + DSU Key directly in header.
Flow mode: calls GetUserRole and applies returned role + dsuKey.

DSU FILTERING
-------------
Tasks list will be filtered to assignedUserDsuKey == DSU Key (case-insensitive)
when role == DSU and dsuKey provided.

RECOMMENDED SERVER ENFORCEMENT
------------------------------
Implement DSU scoping in ListTasks flow by applying OData filter on AssgnedTpUserDSU.
