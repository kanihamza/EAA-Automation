/**
 * role-helper.js
 * Role resolution + capability checks + UI toggles (client-side).
 *
 * SECURITY NOTE:
 * Client-side RBAC is for UX. Server-side enforcement must be applied in flows.
 */

let ROLE_CTX = {
  mode: 'manual',     // 'manual' | 'flow'
  role: 'DSU',        // 'DG' | 'DSU' | 'Admin'
  dsuKey: '',         // for DSU scoping (e.g., 'POL')
  displayName: 'User'
};

let ROLE_CONFIG = null;

async function loadRoleConfig(url = '/role-config.json') {
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new Error('Failed to load role-config.json (HTTP ' + res.status + ')');
  ROLE_CONFIG = await res.json();
  ROLE_CTX.mode = ROLE_CONFIG.defaultMode || 'manual';
  ROLE_CTX.role = ROLE_CONFIG.defaultRole || 'DSU';
  return ROLE_CONFIG;
}

function setRoleContext(ctx) {
  ROLE_CTX = { ...ROLE_CTX, ...ctx };
  // persist minimal context for refresh continuity
  localStorage.setItem('dgceo.role.ctx', JSON.stringify({
    mode: ROLE_CTX.mode,
    role: ROLE_CTX.role,
    dsuKey: ROLE_CTX.dsuKey,
    displayName: ROLE_CTX.displayName
  }));
}

function loadRoleContextFromStorage() {
  try {
    const raw = localStorage.getItem('dgceo.role.ctx');
    if (!raw) return null;
    const ctx = JSON.parse(raw);
    ROLE_CTX = { ...ROLE_CTX, ...ctx };
    return ROLE_CTX;
  } catch {
    return null;
  }
}

function getRoleContext() {
  return ROLE_CTX;
}

function hasCapability(capability) {
  const r = ROLE_CTX.role;
  const caps = ROLE_CONFIG?.roles?.[r]?.capabilities || [];
  return caps.includes(capability);
}

/**
 * Optional server-backed resolution via flow.
 * The flow should return: { role: 'DG'|'DSU'|'Admin', dsuKey: 'POL', displayName: 'Name' }
 */
async function resolveRoleViaFlow(flowUrl, identity = {}) {
  const res = await fetch(flowUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(identity || {})
  });
  if (!res.ok) throw new Error('Role flow error HTTP ' + res.status);
  const data = await res.json();
  setRoleContext({
    mode: 'flow',
    role: data.role || 'DSU',
    dsuKey: data.dsuKey || '',
    displayName: data.displayName || 'User'
  });
  return getRoleContext();
}

export {
  loadRoleConfig,
  loadRoleContextFromStorage,
  resolveRoleViaFlow,
  setRoleContext,
  getRoleContext,
  hasCapability
};
