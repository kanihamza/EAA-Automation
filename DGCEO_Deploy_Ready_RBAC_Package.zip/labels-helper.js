/**
 * DGCEO Frontend Labels Loader
 * Loads labels.json and exposes helper functions.
 *
 * Usage:
 *   import { loadLabels, labelFor, dropdownOptions } from './labels-helper.js';
 *   await loadLabels('/labels.json');
 *   const col = labelFor('Global_Tracking_Queue', 'referenceId');
 */

let LABELS = null;

async function loadLabels(url = '/labels.json') {
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) {
    throw new Error('Failed to load labels.json (HTTP ' + res.status + ')');
  }
  LABELS = await res.json();
  return LABELS;
}

function labelFor(listKey, fieldKey) {
  return LABELS?.lists?.[listKey]?.columns?.[fieldKey] || fieldKey;
}

function listDisplayName(listKey) {
  return LABELS?.lists?.[listKey]?.displayName || listKey;
}

function dropdownOptions(key) {
  return LABELS?.dropdowns?.[key]?.options || [];
}

function dropdownLabel(key) {
  return LABELS?.dropdowns?.[key]?.label || key;
}

export {
  loadLabels,
  labelFor,
  listDisplayName,
  dropdownOptions,
  dropdownLabel
};
