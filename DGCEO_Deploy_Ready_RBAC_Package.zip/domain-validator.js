/**
 * Domain JSON Validator against adapter-mapping-config.json
 *
 * Validates returned/posted domain objects against adapter-mapping-config.json
 * to detect schema drift and unexpected fields at runtime.
 *
 * Usage:
 *   import { validateDomain } from './domain-validator.js';
 *   import adapter from './adapter-mapping-config.json' assert { type: 'json' };
 *   const result = validateDomain('Global_Tracking_Queue', taskObj, adapter);
 */

function validateDomain(entityKey, domainObject, adapterConfig) {
  const listCfg = adapterConfig?.lists?.[entityKey];
  if (!listCfg) {
    return { valid: false, errors: [`Unknown entity/list key: ${entityKey}`] };
  }

  const errors = [];
  const mappings = listCfg.domainToSharePoint || {};

  // Reject unexpected fields (except id)
  for (const field of Object.keys(domainObject || {})) {
    if (field === 'id') continue;
    if (!mappings[field]) {
      errors.push(`Unexpected field: ${field}`);
    }
  }

  // Type checks for known fields when present
  for (const [domainField, m] of Object.entries(mappings)) {
    if (!(domainField in (domainObject || {}))) continue;
    const v = domainObject[domainField];
    if (v === null || v === undefined) continue;

    switch (m.type) {
      case 'Number':
        if (typeof v !== 'number') errors.push(`Field ${domainField} must be a number`);
        break;
      case 'Boolean':
        if (typeof v !== 'boolean') errors.push(`Field ${domainField} must be a boolean`);
        break;
      case 'Text':
      case 'Choice':
      case 'Hyperlink':
      case 'Note':
        if (typeof v !== 'string') errors.push(`Field ${domainField} must be a string`);
        break;
      case 'DateTime':
        if (typeof v !== 'string') errors.push(`Field ${domainField} must be an ISO date-time string`);
        break;
      case 'Person':
      case 'PersonMulti':
      case 'Lookup':
        // These are often represented as strings or objects depending on adapter implementation.
        // Keep flexible but at least enforce non-empty when provided.
        // (Optional strict mode can be added later.)
        break;
      default:
        // Unknown type in config; don't fail runtime, but warn
        break;
    }
  }

  return { valid: errors.length === 0, errors };
}

export { validateDomain };
