// api.js
// Simple HTTP client for calling Power Automate flows using the domain models.

async function callFlow(url, method = "GET", body = null) {
  const options = {
    method,
    headers: {
      "Content-Type": "application/json"
      // If you later front flows with an API management gateway or auth,
// you can add Authorization headers here.
    }
  };

  if (body !== null) {
    options.body = JSON.stringify(body);
  }

  const res = await fetch(url, options);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Flow error ${res.status}: ${text}`);
  }
  if (res.status === 204) {
    return null;
  }
  try {
    return await res.json();
  } catch (e) {
    return null;
  }
}

// Domain-specific helpers, aligned with the DGCEO Task and DgoActivity models.

async function listTasks() {
  return callFlow(FLOW_ENDPOINTS.ListTasks, "GET");
}

async function getTaskWithComments(id) {
  return callFlow(FLOW_ENDPOINTS.GetTaskWithComments, "POST", { id });
}

async function createTask(taskPayload) {
  // taskPayload should conform to Task.schema.json (without requiring id)
  return callFlow(FLOW_ENDPOINTS.CreateTask, "POST", taskPayload);
}

async function updateTaskProgress(id, progress) {
  return callFlow(FLOW_ENDPOINTS.UpdateTaskProgress, "POST", { id, progress });
}

async function addTaskComment(commentPayload) {
  // commentPayload should conform to TaskComment.schema.json (without requiring id/timestamp)
  return callFlow(FLOW_ENDPOINTS.AddTaskComment, "POST", commentPayload);
}

async function listDocuments() {
  return callFlow(FLOW_ENDPOINTS.ListDocuments, "GET");
}
