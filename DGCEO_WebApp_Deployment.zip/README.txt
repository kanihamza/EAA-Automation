DGCEO Web App Deployment Package
================================

This package contains a minimal HTML/JavaScript web application for
DGCEO work management, built to integrate with Power Automate HTTP flows
and SharePoint lists using the DGCEO data model and architecture.

CONTENTS
--------

- index.html       : Dashboard (lists Tasks and DGO Documents)
- new-task.html    : Create new Task
- task.html        : Task details (view + update Progress + Comments)
- config.js        : Configuration for Power Automate HTTP flow URLs
- api.js           : Small JS client to call flows
- styles.css       : Basic styling
- README.txt       : This file

REQUIREMENTS
------------

1. A static hosting environment (e.g., InfinityFree, any HTML hosting).
2. Power Automate HTTP-triggered flows for:
   - ListTasks
   - ListDocuments
   - GetTaskWithComments
   - CreateTask
   - UpdateTaskProgress
   - AddTaskComment
3. SharePoint Online lists configured according to:
   "EAA DGCEO Enterprise Data Model & System Architecture".

CONFIGURATION
-------------

1. Open config.js and replace all placeholder URLs, for example:

   const FLOW_ENDPOINTS = {
     ListTasks: "https://prod-xx.logic.azure.com/.../ListTasks",
     GetTaskWithComments: "https://prod-xx.logic.azure.com/.../GetTaskWithComments",
     CreateTask: "https://prod-xx.logic.azure.com/.../CreateTask",
     UpdateTaskProgress: "https://prod-xx.logic.azure.com/.../UpdateTaskProgress",
     AddTaskComment: "https://prod-xx.logic.azure.com/.../AddTaskComment",
     ListDocuments: "https://prod-xx.logic.azure.com/.../ListDocuments"
   };

2. Ensure each flow implements the correct JSON contract:

   - ListTasks:
     * Method: GET
     * Response: JSON array of Task objects, conforming to Task.schema.json.

   - ListDocuments:
     * Method: GET
     * Response: JSON array of DgoActivity objects.

   - GetTaskWithComments:
     * Method: POST
     * Request body: { "id": <taskId> }
     * Response: { "task": Task, "comments": TaskComment[] }

   - CreateTask:
     * Method: POST
     * Request body: Task object without requiring id.
     * Action: SharePoint "Create item" in Global Tracking Queue.
     * Response: created Task with id and other fields populated.

   - UpdateTaskProgress:
     * Method: POST
     * Request body: { "id": <taskId>, "progress": "New|In Progress|Completed|..." }
     * Action: Update Progress column for the task.
     * Response: updated Task (recommended).

   - AddTaskComment:
     * Method: POST
     * Request body: TaskComment-like object:
       { "id": 0, "taskId": <taskId>, "author": null, "comment": "...", "timestamp": null }
     * Action: Create item in Tasks_Comments, link to task via TaskLookup.
     * Response: created Comment object.

DEPLOYMENT TO INFINITYFREE (OR SIMILAR)
---------------------------------------

1. Log into your InfinityFree cPanel / File Manager.
2. Navigate to your domain's root folder (usually htdocs).
3. Upload all files in this package into that folder:
   - index.html
   - new-task.html
   - task.html
   - config.js
   - api.js
   - styles.css
   - README.txt (optional)
4. Confirm that your Power Automate flow URLs in config.js are correct.
5. Visit your domain in a browser:
   - e.g., https://your-subdomain.infinityfreeapp.com/

   You should see the DGCEO Work Management Dashboard.

SECURITY NOTE
-------------

- Calling Power Automate HTTP triggers directly from a browser exposes
  the flow URLs to the client.
- For production use, consider:
  - Protecting flows behind Azure API Management or another gateway.
  - Enforcing authentication & conditional access.
  - Using IP restrictions or network controls where possible.

SUPPORTING DOCUMENT
-------------------

For full details of the data model, list schemas, JSON contracts,
and governance rules, refer to the enterprise document:

"EAA DGCEO Enterprise Data Model & System Architecture (Version 1.0)"

That document is the authoritative reference for data structures and
should be kept alongside this deployment package.
