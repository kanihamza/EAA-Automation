// config.js
// IMPORTANT:
// Replace the placeholder URLs below with your actual Power Automate HTTP trigger URLs.
// Each flow should implement the domain contracts defined in your DGCEO data model document.

const FLOW_ENDPOINTS = {
  ListTasks: "https://YOUR_FLOW_URL_FOR_ListTasks",
  GetTaskWithComments: "https://YOUR_FLOW_URL_FOR_GetTaskWithComments",
  CreateTask: "https://YOUR_FLOW_URL_FOR_CreateTask",
  UpdateTaskProgress: "https://YOUR_FLOW_URL_FOR_UpdateTaskProgress",
  AddTaskComment: "https://YOUR_FLOW_URL_FOR_AddTaskComment",
  ListDocuments: "https://YOUR_FLOW_URL_FOR_ListDocuments"
};
