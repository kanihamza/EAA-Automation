# NITDA Task Creation App

This package contains:

✔ index.html (real production file uploaded by user)
✔ app-config.js
✔ README.md

You must supply lookup and user JSON files separately:
- lookups/categories.json
- lookups/departments.json
- users/users-page1.json
