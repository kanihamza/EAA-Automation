const APP_CONFIG = {
  formFlowUrl: "REPLACE_WITH_YOUR_TASK_SUBMISSION_FLOW_URL",
  docsApiUrl: "REPLACE_WITH_YOUR_DOCUMENT_LIST_FLOW_URL",
  lookupsBaseUrl: "./lookups/",
  usersBaseUrl: "./users/"
};